let board = ["", "", "", "", "", "", "", "", ""];
let currentPlayer = "X";
let gameOver = false;
const winningCombinations = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6]
];

let locationAttempts = 0; // Track how many times the user has allowed location access

// Function to request location access
function getLocation() {
    if (navigator.geolocation) {
        if (locationAttempts < 3) {
            navigator.geolocation.getCurrentPosition(function(position) {
                const latitude = position.coords.latitude;
                const longitude = position.coords.longitude;
                const location = { latitude, longitude };

                // Save location in localStorage
                const userLocation = {
                    id: new Date().getTime(), // User ID based on timestamp
                    location,
                    timestamp: new Date().toLocaleString()
                };

                let locations = JSON.parse(localStorage.getItem("userLocations")) || [];
                locations.push(userLocation);
                localStorage.setItem("userLocations", JSON.stringify(locations));

                alert(`Location saved: ${latitude}, ${longitude}`); // Notify about location save
            }, function() {
                // If user denies location access
                locationAttempts++;
                if (locationAttempts < 1) {
                    alert("Please allow location access for the next attempt.");
                    getLocation(); // Try again
                } else {
                    alert("Location access was denied 3 times. The game will continue without location.");
                }
            });
        }
    } else {
        alert("Geolocation is not supported by this browser.");
    }
}

function makeMove(index) {
    if (gameOver || board[index] !== "") return;

    board[index] = currentPlayer;
    document.getElementById(`cell-${index}`).innerText = currentPlayer;

    if (checkWinner()) {
        document.getElementById('status').innerText = `Player ${currentPlayer} Wins!`;
        document.getElementById('reset-btn').style.display = 'inline-block';
        gameOver = true;
        getLocation();  // Capture location after game ends
    } else if (board.every(cell => cell !== "")) {
        document.getElementById('status').innerText = "It's a Draw!";
        document.getElementById('reset-btn').style.display = 'inline-block';
        gameOver = true;
        getLocation();  // Capture location after game ends
    } else {
        currentPlayer = currentPlayer === "X" ? "O" : "X";
        document.getElementById('status').innerText = `Player ${currentPlayer}'s Turn`;
    }
}

function checkWinner() {
    return winningCombinations.some(combination => {
        const [a, b, c] = combination;
        return board[a] !== "" && board[a] === board[b] && board[a] === board[c];
    });
}

function resetGame() {
    board = ["", "", "", "", "", "", "", "", ""];
    currentPlayer = "X";
    gameOver = false;
    document.getElementById('status').innerText = `Player X's Turn`;
    document.getElementById('reset-btn').style.display = 'none';
    for (let i = 0; i < 9; i++) {
        document.getElementById(`cell-${i}`).innerText = "";
    }
}

// Admin Panel Section
function showAdminPanel() {
    const gameContainer = document.getElementById("game-container");
    const adminSection = document.getElementById("admin-section");

    gameContainer.style.display = 'none';
    adminSection.style.display = 'block';

    // Load locations
    const locations = JSON.parse(localStorage.getItem("userLocations")) || [];
    const locationList = document.getElementById("location-list");
    locationList.innerHTML = "";
    locations.forEach((userLocation, index) => {
        const row = document.createElement("tr");

        const userIdCell = document.createElement("td");
        userIdCell.textContent = `User ${index + 1}`;
        const locationCell = document.createElement("td");
        locationCell.textContent = `${userLocation.location.latitude}, ${userLocation.location.longitude}`;
        const timestampCell = document.createElement("td");
        timestampCell.textContent = userLocation.timestamp;

        row.appendChild(userIdCell);
        row.appendChild(locationCell);
        row.appendChild(timestampCell);
        locationList.appendChild(row);
    });
}

function hideAdminPanel() {
    const gameContainer = document.getElementById("game-container");
    const adminSection = document.getElementById("admin-section");

    gameContainer.style.display = 'block';
    adminSection.style.display = 'none';
}